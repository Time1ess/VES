#include "libdavid.h"


/* Since we only have one decoding thread, the Big Struct
 can be global in case we need it. */
VideoState *gs;
AVFrame *pFrameRGB=av_frame_alloc();


void packet_queue_init(PacketQueue *q)
{
    memset(q, 0, sizeof(PacketQueue));
    q->mutex = SDL_CreateMutex();
    q->cond = SDL_CreateCond();
}


int packet_queue_put(PacketQueue *q, AVPacket *pkt)
{
    
    AVPacketList *pkt1;
    if(av_dup_packet(pkt) < 0)
    {
        return -1;
    }
    pkt1 = (AVPacketList *)av_malloc(sizeof(AVPacketList));
    if(!pkt1)
        return -1;
    pkt1->pkt = *pkt;
    pkt1->next = NULL;
    
    SDL_LockMutex(q->mutex);
    
    if(!q->last_pkt)
        q->first_pkt = pkt1;
    else
        q->last_pkt->next = pkt1;
    q->last_pkt = pkt1;
    q->nb_packets++;
    q->size += pkt1->pkt.size;
    SDL_CondSignal(q->cond);
    
    SDL_UnlockMutex(q->mutex);
    return 0;
}


static int packet_queue_get(PacketQueue *q, AVPacket *pkt, int block)
{
    AVPacketList *pkt1;
    int ret;
    
    SDL_LockMutex(q->mutex);
    for(;;)
    {
        if(gs->quit)
        {
            ret = -1;
            break;
            
        }
        pkt1 = q->first_pkt;
        if(pkt1)
        {
            q->first_pkt = pkt1->next;
            if(!q->first_pkt)
                q->last_pkt = NULL;
            q->nb_packets--;
            q->size -= pkt1->pkt.size;
            *pkt = pkt1->pkt;
            av_free(pkt1);
            ret = 1;
            break;
        }
        else if(!block)
        {
            ret = 0;
            break;
        }
        else
        {
            SDL_CondWait(q->cond, q->mutex);
        }
    }
    SDL_UnlockMutex(q->mutex);
    return ret;
}


int init_picture(VideoState *is, AVFrame *pFrame)
{
 
    if(is->quit||pFrameRGB == NULL)
        return -1;
    
    sws_scale(
              is->sws_ctx,
              (uint8_t const * const *)pFrame->data,
              pFrame->linesize,
              0,
              is->video_st->codec->height,
              pFrameRGB->data,
              pFrameRGB->linesize
              );
    return 0;
}

int video_thread(void *arg)
{
    VideoState *is = (VideoState *)arg;
    AVPacket pkt1, *packet = &pkt1;
    int frameFinished;
    AVFrame *pFrame;
    
    pFrame = av_frame_alloc();
    
    for(;;)
    {
        if(is->quit)
        {
            break;
        }
        if(packet_queue_get(&is->videoq, packet, 1) < 0)
        {
            // means we quit getting packets
            break;
        }
        // Decode video frame
        avcodec_decode_video2(is->video_st->codec, pFrame, &frameFinished, packet);
        
        // Did we get a video frame?
        if(frameFinished)
        {
            // if(init_picture(is, pFrame) < 0)
            //   break;
            //            is->status = 2;
            //is->status = 3;

            init_picture(is, pFrame);
            //fprintf(stdout, "frameFinished\n");
//            SDL_Event       event;
//            event.type = FF_QUIT_EVENT;
//            event.user.data1 = is;
//            SDL_PushEvent(&event);
            
        }
        av_free_packet(packet);
    }
    av_frame_free(&pFrame);
    return 0;
}

int stream_component_open(VideoState *is, int stream_index)
{
    
    AVFormatContext *pFormatCtx = is->pFormatCtx;
    AVCodecContext *codecCtx = NULL;
    
    AVCodec *codec = NULL;
    AVDictionary *optionsDict = NULL;
    
    if(stream_index < 0 || stream_index >= pFormatCtx->nb_streams)
    {
        return -1;
    }
    
    codecCtx = pFormatCtx->streams[stream_index]->codec;
    codec = avcodec_find_decoder(codecCtx->codec_id);
    
    if(!codec || avcodec_open2(codecCtx, codec, &optionsDict) < 0)
    {
        fprintf(stdout, "Unsupported codec!\n");
        return -1;
    }
    
    if(codecCtx->codec_type == AVMEDIA_TYPE_VIDEO)
    {
        is->videoStream = stream_index;
        is->video_st = pFormatCtx->streams[stream_index];
        
        packet_queue_init(&is->videoq);
        is->sws_ctx = sws_getContext
        (
         is->video_st->codec->width,
         is->video_st->codec->height,
         is->video_st->codec->pix_fmt,
//         is->video_st->codec->width,
//         is->video_st->codec->height,
         VIEW_WIDTH,
         VIEW_HEIGHT,
         AV_PIX_FMT_RGB24,
         SWS_BILINEAR,
         NULL,
         NULL,
         NULL
         );
        fprintf(stdout, "create video thread\n");
        is->video_tid = SDL_CreateThread(video_thread, "video thread", is);
    }
    return 0;
}


int decode_interrupt_cb(void *opaque)
{
    return (gs && gs->quit);
}


int decode_thread(void *arg)
{
    VideoState *is = (VideoState *)arg;
    AVFormatContext *pFormatCtx = NULL;
    AVPacket pkt1, *packet = &pkt1;
    
    AVIOInterruptCB callback;
    
    int video_index = -1;
    int i;
    
    is->videoStream=-1;
    
    gs = is;
    // Will interrupt blocking functions ifwe quit!
    callback.callback = decode_interrupt_cb;
    callback.opaque = is;
    
    if(avio_open2(&is->io_context, is->filename, 0, &callback, NULL) < 0)
    {
        fprintf(stdout, "Unable to open I/O for file\n");
        return -1;
    }
    fprintf(stdout, "avio_open2 done\n");
    
    // Open video file
    if(avformat_open_input(&pFormatCtx, is->filename, NULL, NULL)!=0)
    {
        fprintf(stdout, "Couldn't Open file\n");
        return -1; // Couldn't open file
    }
    fprintf(stdout, "open_input done\n");
    
    is->pFormatCtx = pFormatCtx;
    
    // Retrieve stream information
    if(avformat_find_stream_info(pFormatCtx, NULL)<0)
    {
        fprintf(stdout, "Couldn't Retrieve stream information\n");
        return -1; // Couldn't find stream information
    }
    
    // Dump information about file onto standard error
    av_dump_format(pFormatCtx, 0, is->filename, 0);
    
    // Find the first video stream
    for(i=0; i<pFormatCtx->nb_streams; i++)
    {
        if(pFormatCtx->streams[i]->codec->codec_type==AVMEDIA_TYPE_VIDEO &&
           video_index < 0)
        {
            video_index=i;
            break;
        }
    }
    if(video_index == -1)
    {
        fprintf(stdout, "Couldn't find video stream\n");
        return -1;
    }
    fprintf(stdout, "stream component open\n");
    stream_component_open(is, video_index);
    
    // main decode loop
    for(;;)
    {
        if(is->quit)
        {
            break;
        }
        if(av_read_frame(is->pFormatCtx, packet) < 0)
        {
            if(is->pFormatCtx->pb->error == 0)
                continue;
            else
                break;
        }
        if(packet->stream_index == is->videoStream)
            packet_queue_put(&is->videoq, packet);
        else
            av_free_packet(packet);
    }
    return 0;
}

extern "C" int UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API init(char* name, int textureId)
{
    SDL_Event       event;
    VideoState      *is;
    is = (VideoState*)av_mallocz(sizeof(VideoState));
    if(name == NULL) return -1;
    is->status = 1;

    
    // Register all formats and codecs
    av_register_all();
    avformat_network_init();
    if(SDL_Init(SDL_INIT_TIMER|SDL_INIT_VIDEO))
    {
        fprintf(stdout, "Could not initialize SDL\n");
        exit(1);
    }
    
    
    uint8_t *buffer;
    int numBytes;
    numBytes = avpicture_get_size(AV_PIX_FMT_RGB24, VIEW_WIDTH, VIEW_HEIGHT);

    buffer = (uint8_t *) av_malloc(numBytes*sizeof(uint8_t));
    
    avpicture_fill((AVPicture *) pFrameRGB, buffer, AV_PIX_FMT_RGB24,
                   VIEW_WIDTH, VIEW_HEIGHT);
    


    //    av_strlcpy(is->filename, argv[1], sizeof(is->filename));
    strcpy(is->filename, name);
    fprintf(stdout, "create decode thread\n");
    is->textureId = textureId;
    is->parse_tid = SDL_CreateThread(decode_thread, "decode thread", is);
    if(!is->parse_tid)
    {
        av_free(is);
        return -1;
    }
    for(;;)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case FF_QUIT_EVENT:
            case SDL_QUIT:
                is->quit = 1;
                SDL_Quit();
                av_frame_free(&pFrameRGB);
                return 0;
                break;
            default:
                break;
        }
    }
    av_frame_free(&pFrameRGB);
    return 0;
}


//extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API destroy(void *arg)
//{
//    VideoState *is = (VideoState *)arg;
//    av_free(is);
//}

extern "C" int UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API dlltest()
{
    sleep(3);
    return 100;
}

static void UNITY_INTERFACE_API OnRenderEvent(int texID)
{
    GLuint gltex = (GLuint)(size_t)(texID);

    glBindTexture(GL_TEXTURE_2D, gltex);
    
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, VIEW_WIDTH, VIEW_HEIGHT,
                    GL_RGB, GL_UNSIGNED_BYTE, pFrameRGB->data[0]);
    
    //free( bytes );
    return;
}

extern "C" UnityRenderingEvent UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API GetRenderEventFunc()
{
    return OnRenderEvent;
}

extern "C" void UNITY_INTERFACE_EXPORT UNITY_INTERFACE_API RenderFrame(int texID)
{
    GLuint gltex = (GLuint)(size_t)(texID);
    
    glBindTexture(GL_TEXTURE_2D, gltex);
    
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, VIEW_WIDTH, VIEW_HEIGHT,
                    GL_RGB, GL_UNSIGNED_BYTE, pFrameRGB->data[0]);
    
    return;
}


